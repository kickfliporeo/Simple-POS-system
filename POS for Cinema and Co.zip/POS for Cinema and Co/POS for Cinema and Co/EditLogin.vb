﻿
Imports System.IO
Public Class EditLogin
    'these are global variables
    Dim linecount As Integer
    Dim newuserid As Integer
    Dim rowindex As Integer 'keeps track of current row in the data grid
    Private Sub first()
        rowindex = 0

        txt_userid.Text = dgv_users.Rows(rowindex).Cells(0).Value
        txt_username.Text = dgv_users.Rows(rowindex).Cells(1).Value
        txt_password.Text = dgv_users.Rows(rowindex).Cells(2).Value
        txt_level.Text = dgv_users.Rows(rowindex).Cells(3).Value

        dgv_users.ClearSelection() 'clears current blue bar
        dgv_users.Rows(rowindex).Selected = True

    End Sub
    Private Sub last()
        rowindex = linecount - 1 'we count from zero 

        txt_userid.Text = dgv_users.Rows(rowindex).Cells(0).Value
        txt_username.Text = dgv_users.Rows(rowindex).Cells(1).Value
        txt_password.Text = dgv_users.Rows(rowindex).Cells(2).Value
        txt_level.Text = dgv_users.Rows(rowindex).Cells(3).Value

        dgv_users.ClearSelection() 'clears current blue bar
        dgv_users.Rows(rowindex).Selected = True

    End Sub
    Private Sub previous()
        If rowindex > 0 Then
            rowindex = rowindex - 1
        Else
            MsgBox("sorry but we are at the first one")
        End If

        txt_userid.Text = dgv_users.Rows(rowindex).Cells(0).Value
        txt_username.Text = dgv_users.Rows(rowindex).Cells(1).Value
        txt_password.Text = dgv_users.Rows(rowindex).Cells(2).Value
        txt_level.Text = dgv_users.Rows(rowindex).Cells(3).Value

        dgv_users.ClearSelection() 'clears current blue bar
        dgv_users.Rows(rowindex).Selected = True

    End Sub
    Private Sub nextuser()
        If rowindex < (linecount - 1) Then
            rowindex = rowindex + 1
        Else
            MsgBox("sorry but we are at the last one ")
        End If

        txt_userid.Text = dgv_users.Rows(rowindex).Cells(0).Value
        txt_username.Text = dgv_users.Rows(rowindex).Cells(1).Value
        txt_password.Text = dgv_users.Rows(rowindex).Cells(2).Value
        txt_level.Text = dgv_users.Rows(rowindex).Cells(3).Value

        dgv_users.ClearSelection() 'clears current blue bar
        dgv_users.Rows(rowindex).Selected = True


    End Sub
    Private Sub fillgrid()
        dgv_users.Rows.Clear()
        'this finds out how many records are in the user.txt file
        linecount = File.ReadAllLines(fileloc_user).Length

        Dim sr As New StreamReader(fileloc_user)
        Dim oneline As String
        Dim oneuser() As String

        While sr.Peek() >= 0
            oneline = sr.ReadLine()
            oneuser = oneline.Split(",")

            Dim index = dgv_users.Rows.Add
            dgv_users.Rows(index).SetValues(oneuser)

        End While
        sr.Close()
        dgv_users.RowHeadersVisible = False
    End Sub
    Private Sub EditLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        setfilelocations()
        setbuttons()
        fillgrid()
        first()

    End Sub
    Private Sub setbuttons()
        btn_savenew.Enabled = True
        btn_addnew.Enabled = True
        btn_deletecurrent.Enabled = True
        btn_saveedit.Enabled = True

        btn_first.Enabled = True
        btn_last.Enabled = True
        btn_next.Enabled = True
        btn_previous.Enabled = True
    End Sub

    Private Sub btn_addnew_Click(sender As Object, e As EventArgs) Handles btn_addnew.Click
        Dim max As Integer = -1
        Dim counter As Integer

        btn_savenew.Enabled = True
        txt_username.Clear()
        txt_password.Clear()
        txt_level.Clear()
        'change status of buttons 

        For counter = 0 To (linecount - 1)


            If dgv_users.Rows(counter).Cells(0).Value > max Then
                max = dgv_users.Rows(counter).Cells(0).Value



            End If
        Next

        newuserid = max + 1
        txt_userid.Text = newuserid

        btn_savenew.Enabled = True
    End Sub

    Private Sub btn_savenew_Click(sender As Object, e As EventArgs) Handles btn_savenew.Click

        Dim newuser As String
        Dim newusername As String
        Dim newpassword As String
        Dim newlevel As Integer

        btn_savenew.Enabled = False
        newusername = txt_username.Text
        newpassword = txt_password.Text 'can use encryption here
        newlevel = Val(txt_level.Text)

        newuser = newuserid & "," & newusername & "," & newpassword & "," & newlevel

        Dim sw As New StreamWriter(fileloc_user, True)

        sw.WriteLine(newuser)
        sw.Close()
        fillgrid()


        btn_savenew.Enabled = False
    End Sub

    Private Sub btn_first_Click(sender As Object, e As EventArgs) Handles btn_first.Click

        first()


    End Sub

    Private Sub btn_last_Click(sender As Object, e As EventArgs) Handles btn_last.Click

        last()
    End Sub

    Private Sub btn_previous_Click(sender As Object, e As EventArgs) Handles btn_previous.Click
        previous()
    End Sub
    Private Sub btn_next_Click(sender As Object, e As EventArgs) Handles btn_next.Click
        nextuser()

    End Sub

    Private Sub btn_deletecurrent_Click(sender As Object, e As EventArgs) Handles btn_deletecurrent.Click
        Dim lookingat_userid As Integer
        Dim lookingat_username As String
        Dim lookingat_password As String
        Dim lookingat_level As Integer
        Dim counter As Integer

        If MsgBox("are you sure you wish to delete?", vbYesNo) = vbYes Then
            Dim sw As New StreamWriter(fileloc_user, False)

            For counter = 0 To (linecount - 1)

                lookingat_userid = dgv_users.Rows(counter).Cells(0).Value
                lookingat_username = dgv_users.Rows(counter).Cells(1).Value
                lookingat_password = dgv_users.Rows(counter).Cells(2).Value
                lookingat_level = dgv_users.Rows(counter).Cells(3).Value

                If lookingat_userid <> txt_userid.Text Then

                    sw.WriteLine(lookingat_userid & "," & lookingat_username & "," & lookingat_password & "," & lookingat_level)

                End If
            Next

            sw.Close()

            MsgBox("record as been deleted")

        End If
        first()
        fillgrid()

    End Sub
    Private Sub btn_saveedit_Click(sender As Object, e As EventArgs) Handles btn_saveedit.Click
        Dim lookingat_userid As Integer
        Dim lookingat_username As String
        Dim lookingat_password As String
        Dim lookingat_level As Integer
        Dim counter As Integer

        If MsgBox("are you sure you wish to edit?", vbYesNo) = vbYes Then
            'confirms edit 

            Dim sw As New StreamWriter(fileloc_user, False)


            For counter = 0 To (linecount - 1)

                lookingat_userid = dgv_users.Rows(counter).Cells(0).Value
                lookingat_username = dgv_users.Rows(counter).Cells(1).Value
                lookingat_password = dgv_users.Rows(counter).Cells(2).Value
                lookingat_level = dgv_users.Rows(counter).Cells(3).Value

                If lookingat_userid <> txt_userid.Text Then

                    sw.WriteLine(lookingat_userid & "," & lookingat_username & "," & lookingat_password & "," & lookingat_level)
                Else
                    sw.WriteLine(txt_userid.Text & "," & txt_username.Text & "," & txt_password.Text & "," & txt_password.Text)

                End If
            Next

            sw.Close()

            MsgBox("record as been edited")

        End If
        fillgrid()
    End Sub


    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        Me.Visible = False
        MainMenu.Visible = True

    End Sub
End Class