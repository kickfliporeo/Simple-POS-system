﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SeatVeiwing
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_movie = New System.Windows.Forms.Label()
        Me.txt_movieoutput = New System.Windows.Forms.TextBox()
        Me.pbx_screen = New System.Windows.Forms.PictureBox()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txt_seatbookings = New System.Windows.Forms.TextBox()
        Me.btn_back = New System.Windows.Forms.Button()
        CType(Me.pbx_screen, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_movie
        '
        Me.lbl_movie.AutoSize = True
        Me.lbl_movie.Location = New System.Drawing.Point(499, 39)
        Me.lbl_movie.Name = "lbl_movie"
        Me.lbl_movie.Size = New System.Drawing.Size(40, 15)
        Me.lbl_movie.TabIndex = 53
        Me.lbl_movie.Text = "Movie"
        '
        'txt_movieoutput
        '
        Me.txt_movieoutput.Location = New System.Drawing.Point(447, 57)
        Me.txt_movieoutput.Name = "txt_movieoutput"
        Me.txt_movieoutput.ReadOnly = True
        Me.txt_movieoutput.Size = New System.Drawing.Size(150, 23)
        Me.txt_movieoutput.TabIndex = 52
        '
        'pbx_screen
        '
        Me.pbx_screen.Image = Global.POS_for_Cinema_and_Co.My.Resources.Resources.screen
        Me.pbx_screen.Location = New System.Drawing.Point(35, 12)
        Me.pbx_screen.Name = "pbx_screen"
        Me.pbx_screen.Size = New System.Drawing.Size(284, 68)
        Me.pbx_screen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbx_screen.TabIndex = 80
        Me.pbx_screen.TabStop = False
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(267, 337)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(52, 52)
        Me.Button21.TabIndex = 79
        Me.Button21.Text = "E5"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(209, 337)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(52, 52)
        Me.Button22.TabIndex = 78
        Me.Button22.Text = "D5"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(151, 337)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(52, 52)
        Me.Button23.TabIndex = 77
        Me.Button23.Text = "C5"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(93, 337)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(52, 52)
        Me.Button24.TabIndex = 76
        Me.Button24.Text = "B5"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(35, 337)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(52, 52)
        Me.Button25.TabIndex = 75
        Me.Button25.Text = "A5"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(267, 279)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(52, 52)
        Me.Button16.TabIndex = 74
        Me.Button16.Text = "E4"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(209, 279)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(52, 52)
        Me.Button17.TabIndex = 73
        Me.Button17.Text = "D4"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(151, 279)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(52, 52)
        Me.Button18.TabIndex = 72
        Me.Button18.Text = "C4"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(93, 279)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(52, 52)
        Me.Button19.TabIndex = 71
        Me.Button19.Text = "B4"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(35, 279)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(52, 52)
        Me.Button20.TabIndex = 70
        Me.Button20.Text = "A4"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(267, 221)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(52, 52)
        Me.Button11.TabIndex = 69
        Me.Button11.Text = "E3"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(209, 221)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(52, 52)
        Me.Button12.TabIndex = 68
        Me.Button12.Text = "D3"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(151, 221)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(52, 52)
        Me.Button13.TabIndex = 67
        Me.Button13.Text = "C3"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(93, 221)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(52, 52)
        Me.Button14.TabIndex = 66
        Me.Button14.Text = "B3"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(35, 221)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(52, 52)
        Me.Button15.TabIndex = 65
        Me.Button15.Text = "A3"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(267, 163)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(52, 52)
        Me.Button6.TabIndex = 64
        Me.Button6.Text = "E2"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(209, 163)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(52, 52)
        Me.Button7.TabIndex = 63
        Me.Button7.Text = "D2"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(151, 163)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(52, 52)
        Me.Button8.TabIndex = 62
        Me.Button8.Text = "C2"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(93, 163)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(52, 52)
        Me.Button9.TabIndex = 61
        Me.Button9.Text = "B2"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(35, 163)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(52, 52)
        Me.Button10.TabIndex = 60
        Me.Button10.Text = "A2"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(267, 105)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(52, 52)
        Me.Button5.TabIndex = 59
        Me.Button5.Text = "E1"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(209, 105)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(52, 52)
        Me.Button4.TabIndex = 58
        Me.Button4.Text = "D1"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(151, 105)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(52, 52)
        Me.Button3.TabIndex = 57
        Me.Button3.Text = "C1"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(93, 105)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(52, 52)
        Me.Button2.TabIndex = 56
        Me.Button2.Text = "B1"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(35, 105)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(52, 52)
        Me.Button1.TabIndex = 55
        Me.Button1.Text = "A1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txt_seatbookings
        '
        Me.txt_seatbookings.Location = New System.Drawing.Point(447, 121)
        Me.txt_seatbookings.Multiline = True
        Me.txt_seatbookings.Name = "txt_seatbookings"
        Me.txt_seatbookings.ReadOnly = True
        Me.txt_seatbookings.Size = New System.Drawing.Size(150, 268)
        Me.txt_seatbookings.TabIndex = 81
        '
        'btn_back
        '
        Me.btn_back.BackColor = System.Drawing.Color.DarkOrange
        Me.btn_back.Location = New System.Drawing.Point(328, 395)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(100, 43)
        Me.btn_back.TabIndex = 82
        Me.btn_back.Text = "Exit to booking"
        Me.btn_back.UseVisualStyleBackColor = False
        '
        'SeatVeiwing
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(649, 450)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.txt_seatbookings)
        Me.Controls.Add(Me.pbx_screen)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lbl_movie)
        Me.Controls.Add(Me.txt_movieoutput)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SeatVeiwing"
        Me.Text = "SeatVeiwing"
        CType(Me.pbx_screen, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl_movie As Label
    Friend WithEvents pbx_screen As PictureBox
    Friend WithEvents Button21 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button20 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents txt_seatbookings As TextBox
    Friend WithEvents btn_back As Button
    Public WithEvents txt_movieoutput As TextBox
End Class
