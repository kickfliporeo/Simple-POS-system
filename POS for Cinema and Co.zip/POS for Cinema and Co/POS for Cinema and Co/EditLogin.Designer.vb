﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgv_users = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btn_first = New System.Windows.Forms.Button()
        Me.btn_previous = New System.Windows.Forms.Button()
        Me.btn_next = New System.Windows.Forms.Button()
        Me.btn_last = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_userid = New System.Windows.Forms.TextBox()
        Me.txt_username = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_level = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_password = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btn_addnew = New System.Windows.Forms.Button()
        Me.btn_savenew = New System.Windows.Forms.Button()
        Me.btn_deletecurrent = New System.Windows.Forms.Button()
        Me.btn_saveedit = New System.Windows.Forms.Button()
        Me.btn_exit = New System.Windows.Forms.Button()
        CType(Me.dgv_users, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgv_users
        '
        Me.dgv_users.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_users.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4})
        Me.dgv_users.Location = New System.Drawing.Point(33, 9)
        Me.dgv_users.Name = "dgv_users"
        Me.dgv_users.RowTemplate.Height = 25
        Me.dgv_users.Size = New System.Drawing.Size(721, 242)
        Me.dgv_users.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column1.HeaderText = "ID"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'Column2
        '
        Me.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column2.HeaderText = "Username"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'Column3
        '
        Me.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column3.HeaderText = "Password"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'Column4
        '
        Me.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column4.HeaderText = "Level"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'btn_first
        '
        Me.btn_first.Location = New System.Drawing.Point(205, 257)
        Me.btn_first.Name = "btn_first"
        Me.btn_first.Size = New System.Drawing.Size(68, 39)
        Me.btn_first.TabIndex = 1
        Me.btn_first.Text = "|<"
        Me.btn_first.UseVisualStyleBackColor = True
        '
        'btn_previous
        '
        Me.btn_previous.Location = New System.Drawing.Point(279, 257)
        Me.btn_previous.Name = "btn_previous"
        Me.btn_previous.Size = New System.Drawing.Size(68, 39)
        Me.btn_previous.TabIndex = 2
        Me.btn_previous.Text = "<<"
        Me.btn_previous.UseVisualStyleBackColor = True
        '
        'btn_next
        '
        Me.btn_next.Location = New System.Drawing.Point(353, 257)
        Me.btn_next.Name = "btn_next"
        Me.btn_next.Size = New System.Drawing.Size(68, 39)
        Me.btn_next.TabIndex = 3
        Me.btn_next.Text = ">>"
        Me.btn_next.UseVisualStyleBackColor = True
        '
        'btn_last
        '
        Me.btn_last.Location = New System.Drawing.Point(427, 257)
        Me.btn_last.Name = "btn_last"
        Me.btn_last.Size = New System.Drawing.Size(68, 39)
        Me.btn_last.TabIndex = 4
        Me.btn_last.Text = ">|"
        Me.btn_last.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 320)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 15)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "User ID"
        '
        'txt_userid
        '
        Me.txt_userid.Location = New System.Drawing.Point(93, 317)
        Me.txt_userid.Name = "txt_userid"
        Me.txt_userid.ReadOnly = True
        Me.txt_userid.Size = New System.Drawing.Size(115, 23)
        Me.txt_userid.TabIndex = 6
        '
        'txt_username
        '
        Me.txt_username.Location = New System.Drawing.Point(93, 346)
        Me.txt_username.Name = "txt_username"
        Me.txt_username.Size = New System.Drawing.Size(115, 23)
        Me.txt_username.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 352)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 15)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Username"
        '
        'txt_level
        '
        Me.txt_level.Location = New System.Drawing.Point(93, 404)
        Me.txt_level.Name = "txt_level"
        Me.txt_level.Size = New System.Drawing.Size(115, 23)
        Me.txt_level.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 407)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 15)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Level"
        '
        'txt_password
        '
        Me.txt_password.Location = New System.Drawing.Point(93, 375)
        Me.txt_password.Name = "txt_password"
        Me.txt_password.Size = New System.Drawing.Size(115, 23)
        Me.txt_password.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(27, 378)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 15)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Password"
        '
        'btn_addnew
        '
        Me.btn_addnew.Location = New System.Drawing.Point(555, 272)
        Me.btn_addnew.Name = "btn_addnew"
        Me.btn_addnew.Size = New System.Drawing.Size(81, 34)
        Me.btn_addnew.TabIndex = 13
        Me.btn_addnew.Text = "Add"
        Me.btn_addnew.UseVisualStyleBackColor = True
        '
        'btn_savenew
        '
        Me.btn_savenew.Location = New System.Drawing.Point(642, 272)
        Me.btn_savenew.Name = "btn_savenew"
        Me.btn_savenew.Size = New System.Drawing.Size(81, 34)
        Me.btn_savenew.TabIndex = 14
        Me.btn_savenew.Text = "Save"
        Me.btn_savenew.UseVisualStyleBackColor = True
        '
        'btn_deletecurrent
        '
        Me.btn_deletecurrent.Location = New System.Drawing.Point(579, 312)
        Me.btn_deletecurrent.Name = "btn_deletecurrent"
        Me.btn_deletecurrent.Size = New System.Drawing.Size(121, 34)
        Me.btn_deletecurrent.TabIndex = 15
        Me.btn_deletecurrent.Text = "Delete Current User"
        Me.btn_deletecurrent.UseVisualStyleBackColor = True
        '
        'btn_saveedit
        '
        Me.btn_saveedit.Location = New System.Drawing.Point(579, 352)
        Me.btn_saveedit.Name = "btn_saveedit"
        Me.btn_saveedit.Size = New System.Drawing.Size(121, 34)
        Me.btn_saveedit.TabIndex = 16
        Me.btn_saveedit.Text = "Edit save"
        Me.btn_saveedit.UseVisualStyleBackColor = True
        '
        'btn_exit
        '
        Me.btn_exit.BackColor = System.Drawing.Color.Red
        Me.btn_exit.Location = New System.Drawing.Point(697, 404)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(91, 39)
        Me.btn_exit.TabIndex = 17
        Me.btn_exit.Text = "Exit to menu"
        Me.btn_exit.UseVisualStyleBackColor = False
        '
        'EditLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.btn_saveedit)
        Me.Controls.Add(Me.btn_deletecurrent)
        Me.Controls.Add(Me.btn_savenew)
        Me.Controls.Add(Me.btn_addnew)
        Me.Controls.Add(Me.txt_level)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_password)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_username)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_userid)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_last)
        Me.Controls.Add(Me.btn_next)
        Me.Controls.Add(Me.btn_previous)
        Me.Controls.Add(Me.btn_first)
        Me.Controls.Add(Me.dgv_users)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "EditLogin"
        Me.Text = "EditLogin"
        CType(Me.dgv_users, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgv_users As DataGridView
    Friend WithEvents btn_first As Button
    Friend WithEvents btn_previous As Button
    Friend WithEvents btn_next As Button
    Friend WithEvents btn_last As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_userid As TextBox
    Friend WithEvents txt_username As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_level As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_password As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btn_addnew As Button
    Friend WithEvents btn_savenew As Button
    Friend WithEvents btn_deletecurrent As Button
    Friend WithEvents btn_saveedit As Button
    Friend WithEvents btn_exit As Button
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
End Class
