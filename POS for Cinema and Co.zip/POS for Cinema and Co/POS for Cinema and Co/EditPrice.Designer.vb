﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditPrice
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgv_price = New System.Windows.Forms.DataGridView()
        Me.btn_first = New System.Windows.Forms.Button()
        Me.btn_previous = New System.Windows.Forms.Button()
        Me.btn_next = New System.Windows.Forms.Button()
        Me.btn_last = New System.Windows.Forms.Button()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn_save = New System.Windows.Forms.Button()
        Me.btn_clearselection = New System.Windows.Forms.Button()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_snackdrink = New System.Windows.Forms.TextBox()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgv_price, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgv_price
        '
        Me.dgv_price.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_price.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column2, Me.Column1})
        Me.dgv_price.Location = New System.Drawing.Point(42, 12)
        Me.dgv_price.Name = "dgv_price"
        Me.dgv_price.RowTemplate.Height = 25
        Me.dgv_price.Size = New System.Drawing.Size(713, 215)
        Me.dgv_price.TabIndex = 0
        '
        'btn_first
        '
        Me.btn_first.Location = New System.Drawing.Point(204, 243)
        Me.btn_first.Name = "btn_first"
        Me.btn_first.Size = New System.Drawing.Size(76, 38)
        Me.btn_first.TabIndex = 1
        Me.btn_first.Text = "|<"
        Me.btn_first.UseVisualStyleBackColor = True
        '
        'btn_previous
        '
        Me.btn_previous.Location = New System.Drawing.Point(286, 243)
        Me.btn_previous.Name = "btn_previous"
        Me.btn_previous.Size = New System.Drawing.Size(76, 38)
        Me.btn_previous.TabIndex = 2
        Me.btn_previous.Text = "<<"
        Me.btn_previous.UseVisualStyleBackColor = True
        '
        'btn_next
        '
        Me.btn_next.Location = New System.Drawing.Point(368, 243)
        Me.btn_next.Name = "btn_next"
        Me.btn_next.Size = New System.Drawing.Size(76, 38)
        Me.btn_next.TabIndex = 3
        Me.btn_next.Text = ">>"
        Me.btn_next.UseVisualStyleBackColor = True
        '
        'btn_last
        '
        Me.btn_last.Location = New System.Drawing.Point(450, 243)
        Me.btn_last.Name = "btn_last"
        Me.btn_last.Size = New System.Drawing.Size(76, 38)
        Me.btn_last.TabIndex = 4
        Me.btn_last.Text = ">|"
        Me.btn_last.UseVisualStyleBackColor = True
        '
        'txt_price
        '
        Me.txt_price.Location = New System.Drawing.Point(119, 297)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(111, 23)
        Me.txt_price.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(51, 300)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 15)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Price ID"
        '
        'btn_save
        '
        Me.btn_save.Location = New System.Drawing.Point(542, 283)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(101, 37)
        Me.btn_save.TabIndex = 11
        Me.btn_save.Text = "Save"
        Me.btn_save.UseVisualStyleBackColor = True
        '
        'btn_clearselection
        '
        Me.btn_clearselection.Location = New System.Drawing.Point(542, 326)
        Me.btn_clearselection.Name = "btn_clearselection"
        Me.btn_clearselection.Size = New System.Drawing.Size(101, 37)
        Me.btn_clearselection.TabIndex = 12
        Me.btn_clearselection.Text = "Clear selection"
        Me.btn_clearselection.UseVisualStyleBackColor = True
        '
        'btn_exit
        '
        Me.btn_exit.BackColor = System.Drawing.Color.Red
        Me.btn_exit.Location = New System.Drawing.Point(674, 393)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(101, 45)
        Me.btn_exit.TabIndex = 13
        Me.btn_exit.Text = "Exit to menu"
        Me.btn_exit.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 329)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 15)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Snack or Drink ID"
        '
        'txt_snackdrink
        '
        Me.txt_snackdrink.Location = New System.Drawing.Point(119, 326)
        Me.txt_snackdrink.Name = "txt_snackdrink"
        Me.txt_snackdrink.Size = New System.Drawing.Size(111, 23)
        Me.txt_snackdrink.TabIndex = 25
        '
        'Column2
        '
        Me.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column2.HeaderText = "Snack or Drink ID"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column1.HeaderText = "Price ID"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'EditPrice
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_snackdrink)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.btn_clearselection)
        Me.Controls.Add(Me.btn_save)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.btn_last)
        Me.Controls.Add(Me.btn_next)
        Me.Controls.Add(Me.btn_previous)
        Me.Controls.Add(Me.btn_first)
        Me.Controls.Add(Me.dgv_price)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "EditPrice"
        Me.Text = "EditPrice"
        CType(Me.dgv_price, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgv_price As DataGridView
    Friend WithEvents btn_first As Button
    Friend WithEvents btn_previous As Button
    Friend WithEvents btn_next As Button
    Friend WithEvents btn_last As Button
    Friend WithEvents txt_price As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_save As Button
    Friend WithEvents btn_clearselection As Button
    Friend WithEvents btn_exit As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_snackdrink As TextBox
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
End Class
