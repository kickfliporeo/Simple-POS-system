﻿Imports System.IO

Public Class Form1
    Dim userfile As String
    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        getpath()
        userfile = activepath & "\userfile.txt" 'when the form loads up,it goes to the active path file location and adds \userfile.txt

        If Dir$(userfile) = "" Then 'this checks if the file exists in that location. If the file does not exist, it would create a path
            Dim sw As New System.IO.StreamWriter(userfile, True)

            sw.Close()
            MsgBox("user.txt has been created")
        End If



    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        Application.Exit()
        'exits the application

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_login.Click

        Dim username As String
        Dim password As String
        Dim match As Boolean

        Dim onerecord As String 'one line of the text file
        Dim oneuser() As String 'array to hold one field in each slot

        username = txt_username.Text
        password = txt_password.Text

        match = False

        Dim sr As New System.IO.StreamReader(userfile)
        'write code to check for match
        While sr.Peek() >= 0 'it looks for every single line in the text file until there are no more and drops out of the loop

            onerecord = sr.ReadLine()
            oneuser = onerecord.Split(",") ' the dim is using the record is splitting the string in the text file
            If UCase((username = oneuser(1))) And (password = oneuser(2)) Then 'ucase means that the username is not case sensitive

                match = True
                sercuritylevel = oneuser(3)
                Exit While 'stops the loop 
            End If
        End While

        sr.Close()
        If match = True Then

            MainMenu.Visible = True
            Me.Visible = False

        Else
            MsgBox("Login unsuccessful. Please try again.")
            txt_username.Clear()
            txt_password.Clear()
        End If

    End Sub


End Class
