﻿Imports System.Data.SqlTypes
Imports System.Diagnostics.CodeAnalysis
Imports System.IO
Public Class SeatBooking
    Dim linecount As Integer
    Dim newseatid As Integer
    Dim rowindex As Integer
    Dim coordinates As String


    Private Sub fillgrid()

        dgv_seat.Rows.Clear()

        linecount = File.ReadAllLines(fileloc_seat).Length

        Dim sr As New StreamReader(fileloc_seat)
        Dim oneline As String
        Dim oneuser() As String

        While sr.Peek() >= 0

            oneline = sr.ReadLine()
            oneuser = oneline.Split(",")

            Dim index = dgv_seat.Rows.Add
            dgv_seat.Rows(index).SetValues(oneuser)

        End While

        sr.Close()

        dgv_seat.RowHeadersVisible = False
    End Sub
    Private Sub setbuttons()

        btn_save.Enabled = True
        btn_clearselection.Enabled = True
        btn_clearall.Enabled = True


    End Sub


    Private Sub Button30_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        Me.Visible = False
        MainMenu.Visible = True
        'goes  back to the main menu 

    End Sub

    Private Sub Button29_Click(sender As Object, e As EventArgs) Handles btn_seatveiw.Click

        Me.Visible = False
        Dim f2 As New SeatVeiwing(Me)
        f2.ShowDialog()




        'changes to the seat veiwer 
    End Sub

    Private Sub SeatBooking_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        rbtn_yes.Checked = False
        rbtn_no.Checked = False

        setfilelocations()
        setbuttons()
        fillgrid()


    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        Dim Seatbooking As String

        Dim newforename As String
        Dim newsurname As String
        Dim newpartyno As Integer
        Dim newassistance As String = String.Empty

        newforename = txt_forename.Text
        newsurname = txt_surname.Text
        newpartyno = Val(txt_partyno.Text)
        If rbtn_yes.Checked = True Then
            newassistance = "YES"
        End If
        If rbtn_no.Checked = True Then
            newassistance = "NO"
        End If


        'search first column on datagrid to find a match for selected seat.
        'once found, store details on data grid
        'then save data grid to text file

        For counter = 0 To dgv_seat.Rows.Count - 1

            If dgv_seat.Rows(counter).Cells(0).Value = coordinates Then
                dgv_seat.Rows(counter).Cells(1).Value = txt_forename.Text
                dgv_seat.Rows(counter).Cells(2).Value = txt_surname.Text
                dgv_seat.Rows(counter).Cells(3).Value = Val(txt_partyno.Text)
                dgv_seat.Rows(counter).Cells(4).Value = newassistance

            End If
        Next

        Dim sw As New StreamWriter(fileloc_seat, False)  'be careful... file is wiped!!!
        For counter = 0 To dgv_seat.Rows.Count - 2

            Seatbooking = dgv_seat.Rows(counter).Cells(0).Value & "," & dgv_seat.Rows(counter).Cells(1).Value & "," & dgv_seat.Rows(counter).Cells(2).Value & "," & dgv_seat.Rows(counter).Cells(3).Value & "," & dgv_seat.Rows(counter).Cells(4).Value
            sw.WriteLine(Seatbooking)
        Next


        sw.Close()

        fillgrid()


        txt_forename.Text = ""
        txt_surname.Text = ""
        txt_partyno.Text = ""




        btn_save.Enabled = True
    End Sub

    Private Sub btn_clearselection_Click(sender As Object, e As EventArgs) Handles btn_clearselection.Click

        Dim lookingat_forename As String
        Dim lookingat_surname As String
        Dim lookingat_partyno As String
        Dim lookingat_assistance As String
        Dim counter As Integer

        If MsgBox("Are you sure you wish to delete?", vbYesNo) = vbYes Then

            Dim sw As New StreamWriter(fileloc_seat, False)

            For counter = 0 To (linecount)

                lookingat_forename = dgv_seat.Rows(counter).Cells(1).Value
                lookingat_surname = dgv_seat.Rows(counter).Cells(2).Value
                lookingat_partyno = dgv_seat.Rows(counter).Cells(3).Value
                lookingat_assistance = dgv_seat.Rows(counter).Cells(4).Value

                If lookingat_forename <> txt_forename.Text Then

                    sw.WriteLine(lookingat_forename & "," & lookingat_surname & "," & lookingat_partyno & "," & lookingat_assistance)

                End If

            Next

            sw.Close()
            MsgBox("Data has been deleted")

        End If

        fillgrid()
    End Sub



    Private Sub btn_A1_Click(sender As Object, e As MouseEventArgs) Handles btn_A1.Click

        coordinates = "A1" 'the coordinates for the seat 

    End Sub

    Private Sub btn_A2_Click(sender As Object, e As EventArgs) Handles btn_A2.Click
        coordinates = "A2"
    End Sub

    Private Sub btn_B1_Click(sender As Object, e As EventArgs) Handles btn_B1.Click
        coordinates = "B1"
    End Sub

    Private Sub btn_E5_Click(sender As Object, e As EventArgs) Handles btn_E5.Click

        coordinates = "E5"
    End Sub

    Private Sub btn_D5_Click(sender As Object, e As EventArgs) Handles btn_D5.Click
        coordinates = "D5"
    End Sub

    Private Sub btn_C5_Click(sender As Object, e As EventArgs) Handles btn_C5.Click
        coordinates = "C5"
    End Sub

    Private Sub btn_B5_Click(sender As Object, e As EventArgs) Handles btn_B5.Click
        coordinates = "B5"
    End Sub

    Private Sub btn_A5_Click(sender As Object, e As EventArgs) Handles btn_A5.Click
        coordinates = "A5"
    End Sub

    Private Sub btn_E4_Click(sender As Object, e As EventArgs) Handles btn_E4.Click
        coordinates = "E4"
    End Sub

    Private Sub btn_D4_Click(sender As Object, e As EventArgs) Handles btn_D4.Click
        coordinates = "D4"
    End Sub

    Private Sub btn_C4_Click(sender As Object, e As EventArgs) Handles btn_C4.Click
        coordinates = "C4"
    End Sub

    Private Sub btn_B4_Click(sender As Object, e As EventArgs) Handles btn_B4.Click
        coordinates = "B4"
    End Sub

    Private Sub btn_A4_Click(sender As Object, e As EventArgs) Handles btn_A4.Click
        coordinates = "A4"
    End Sub

    Private Sub btn_E3_Click(sender As Object, e As EventArgs) Handles btn_E3.Click
        coordinates = "E3"
    End Sub

    Private Sub btn_D3_Click(sender As Object, e As EventArgs) Handles btn_D3.Click
        coordinates = "D3"
    End Sub

    Private Sub btn_C3_Click(sender As Object, e As EventArgs) Handles btn_C3.Click
        coordinates = "C3"
    End Sub

    Private Sub btn_B3_Click(sender As Object, e As EventArgs) Handles btn_B3.Click
        coordinates = "B3"
    End Sub

    Private Sub btn_A3_Click(sender As Object, e As EventArgs) Handles btn_A3.Click
        coordinates = "A3"
    End Sub

    Private Sub btn_E2_Click(sender As Object, e As EventArgs) Handles btn_E2.Click
        coordinates = "E2"
    End Sub

    Private Sub btn_D2_Click(sender As Object, e As EventArgs) Handles btn_D2.Click
        coordinates = "D2"
    End Sub

    Private Sub btn_C2_Click(sender As Object, e As EventArgs) Handles btn_C2.Click
        coordinates = "C2"
    End Sub

    Private Sub btn_B2_Click(sender As Object, e As EventArgs) Handles btn_B2.Click
        coordinates = "B2"
    End Sub

    Private Sub btn_E1_Click(sender As Object, e As EventArgs) Handles btn_E1.Click
        coordinates = "E1"
    End Sub

    Private Sub btn_D1_Click(sender As Object, e As EventArgs) Handles btn_D1.Click
        coordinates = "D1"
    End Sub

    Private Sub btn_C1_Click(sender As Object, e As EventArgs) Handles btn_C1.Click
        coordinates = "C1"
    End Sub
End Class