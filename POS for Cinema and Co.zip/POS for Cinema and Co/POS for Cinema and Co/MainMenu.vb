﻿Public Class MainMenu
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        Me.Visible = False
        'makes the current form disappear
        Form1.Visible = True
        'goes back to the login page

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_sbookings.Click

        Me.Visible = False
        SeatBooking.Visible = True
        'goes to the 'seat bookings' submenu
    End Sub

    Private Sub btn_FandD_Click(sender As Object, e As EventArgs) Handles btn_FandD.Click

        Me.Visible = False
        SnackDrink.Visible = True
        'goes to the 'snack and drink' submenu
    End Sub

    Private Sub btn_csales_Click(sender As Object, e As EventArgs) Handles btn_csales.Click

        Me.Visible = False
        CheckSales.Visible = True
        'goes to the 'check sales' submenu
    End Sub



    Private Sub btn_elogin_Click(sender As Object, e As EventArgs) Handles btn_elogin.Click

        Me.Visible = False
        EditLogin.Visible = True
        'goes back to the login page
    End Sub
End Class