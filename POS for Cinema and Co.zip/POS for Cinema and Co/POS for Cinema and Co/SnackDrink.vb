﻿Public Class SnackDrink
    Private Sub btn_exit_Click(sender As Object, e As EventArgs) Handles btn_exit.Click
        Me.Visible = False
        MainMenu.Visible = True

    End Sub

    Private Sub btn_drink_Click(sender As Object, e As EventArgs) Handles btn_drink.Click
        Me.Visible = False
        Drinkvb.Visible = True

    End Sub

    Private Sub btn_snack_Click(sender As Object, e As EventArgs) Handles btn_snack.Click
        Me.Visible = False
        Snack.Visible = True


    End Sub
End Class