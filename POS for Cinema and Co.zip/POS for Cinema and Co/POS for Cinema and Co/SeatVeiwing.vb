﻿Public Class SeatVeiwing
    Dim f1 As SeatBooking
    Public Sub New(ByVal frm1 As SeatBooking)

        ' This call is required by the designer.
        InitializeComponent()
        f1 = frm1
        ' Add any initialization after the InitializeComponent() call.

    End Sub




    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        Me.Visible = False
        SeatBooking.Visible = True

    End Sub



    Private Sub SeatVeiwing_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txt_movieoutput.Text = f1.txt_movieinput.Text
    End Sub

    Private Sub txt_movieoutput_TextChanged(sender As Object, e As EventArgs) Handles txt_movieoutput.TextChanged

    End Sub
End Class