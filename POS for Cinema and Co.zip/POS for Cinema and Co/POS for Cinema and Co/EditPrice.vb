﻿Public Class EditPrice
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles btn_exit.Click

        Me.Visible = False
        MainMenu.Visible = True

    End Sub

    Private Sub EditPrice_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class