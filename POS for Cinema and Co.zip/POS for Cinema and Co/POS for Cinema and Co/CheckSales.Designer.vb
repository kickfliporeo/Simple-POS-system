﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CheckSales
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.btn_clear = New System.Windows.Forms.Button()
        Me.btn_save = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_snackdrink = New System.Windows.Forms.TextBox()
        Me.txt_stock = New System.Windows.Forms.TextBox()
        Me.btn_last = New System.Windows.Forms.Button()
        Me.btn_next = New System.Windows.Forms.Button()
        Me.btn_previous = New System.Windows.Forms.Button()
        Me.btn_first = New System.Windows.Forms.Button()
        Me.dgv_sales = New System.Windows.Forms.DataGridView()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgv_sales, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Red
        Me.Button7.Location = New System.Drawing.Point(672, 396)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(101, 42)
        Me.Button7.TabIndex = 27
        Me.Button7.Text = "Exit to menu"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'btn_clear
        '
        Me.btn_clear.Location = New System.Drawing.Point(540, 326)
        Me.btn_clear.Name = "btn_clear"
        Me.btn_clear.Size = New System.Drawing.Size(101, 37)
        Me.btn_clear.TabIndex = 26
        Me.btn_clear.Text = "Clear selection"
        Me.btn_clear.UseVisualStyleBackColor = True
        '
        'btn_save
        '
        Me.btn_save.Location = New System.Drawing.Point(540, 283)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(101, 37)
        Me.btn_save.TabIndex = 25
        Me.btn_save.Text = "Save"
        Me.btn_save.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 315)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(97, 15)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Snack or Drink ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(37, 375)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 15)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Stock ID"
        '
        'txt_snackdrink
        '
        Me.txt_snackdrink.Location = New System.Drawing.Point(113, 312)
        Me.txt_snackdrink.Name = "txt_snackdrink"
        Me.txt_snackdrink.ReadOnly = True
        Me.txt_snackdrink.Size = New System.Drawing.Size(111, 23)
        Me.txt_snackdrink.TabIndex = 20
        '
        'txt_stock
        '
        Me.txt_stock.Location = New System.Drawing.Point(113, 372)
        Me.txt_stock.Name = "txt_stock"
        Me.txt_stock.Size = New System.Drawing.Size(111, 23)
        Me.txt_stock.TabIndex = 19
        '
        'btn_last
        '
        Me.btn_last.Location = New System.Drawing.Point(448, 243)
        Me.btn_last.Name = "btn_last"
        Me.btn_last.Size = New System.Drawing.Size(76, 38)
        Me.btn_last.TabIndex = 18
        Me.btn_last.Text = ">|"
        Me.btn_last.UseVisualStyleBackColor = True
        '
        'btn_next
        '
        Me.btn_next.Location = New System.Drawing.Point(366, 243)
        Me.btn_next.Name = "btn_next"
        Me.btn_next.Size = New System.Drawing.Size(76, 38)
        Me.btn_next.TabIndex = 17
        Me.btn_next.Text = ">>"
        Me.btn_next.UseVisualStyleBackColor = True
        '
        'btn_previous
        '
        Me.btn_previous.Location = New System.Drawing.Point(284, 243)
        Me.btn_previous.Name = "btn_previous"
        Me.btn_previous.Size = New System.Drawing.Size(76, 38)
        Me.btn_previous.TabIndex = 16
        Me.btn_previous.Text = "<<"
        Me.btn_previous.UseVisualStyleBackColor = True
        '
        'btn_first
        '
        Me.btn_first.Location = New System.Drawing.Point(202, 243)
        Me.btn_first.Name = "btn_first"
        Me.btn_first.Size = New System.Drawing.Size(76, 38)
        Me.btn_first.TabIndex = 15
        Me.btn_first.Text = "|<"
        Me.btn_first.UseVisualStyleBackColor = True
        '
        'dgv_sales
        '
        Me.dgv_sales.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_sales.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column2, Me.Column3, Me.Column1})
        Me.dgv_sales.Location = New System.Drawing.Point(40, 12)
        Me.dgv_sales.Name = "dgv_sales"
        Me.dgv_sales.RowTemplate.Height = 25
        Me.dgv_sales.Size = New System.Drawing.Size(713, 215)
        Me.dgv_sales.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(40, 346)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 15)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Price ID"
        '
        'txt_price
        '
        Me.txt_price.Location = New System.Drawing.Point(113, 343)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(111, 23)
        Me.txt_price.TabIndex = 28
        '
        'Column2
        '
        Me.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column2.HeaderText = "Snack or Drink ID"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column3.HeaderText = "Price"
        Me.Column3.Name = "Column3"
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Column1.HeaderText = "Stock"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'CheckSales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.btn_clear)
        Me.Controls.Add(Me.btn_save)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_snackdrink)
        Me.Controls.Add(Me.txt_stock)
        Me.Controls.Add(Me.btn_last)
        Me.Controls.Add(Me.btn_next)
        Me.Controls.Add(Me.btn_previous)
        Me.Controls.Add(Me.btn_first)
        Me.Controls.Add(Me.dgv_sales)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "CheckSales"
        Me.Text = "CheckSales"
        CType(Me.dgv_sales, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button7 As Button
    Friend WithEvents btn_clear As Button
    Friend WithEvents btn_save As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_snackdrink As TextBox
    Friend WithEvents txt_stock As TextBox
    Friend WithEvents btn_last As Button
    Friend WithEvents btn_next As Button
    Friend WithEvents btn_previous As Button
    Friend WithEvents btn_first As Button
    Friend WithEvents dgv_sales As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_price As TextBox
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
End Class
