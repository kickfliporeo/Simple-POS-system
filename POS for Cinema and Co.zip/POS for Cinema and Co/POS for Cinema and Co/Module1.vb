﻿Imports System.IO

Module Module1

    'we need to declare variables that will be available in all forms. We do this using a public declaration, instead of DIM

    Public activepath As String 'this variable cas be used anywhere
    Public fileloc_user As String
    Public fileloc_seat As String
    Public fileloc_snackdrink As String
    Public sercuritylevel As Integer 'this variable can be used everywhere also 

    Public Sub getpath()
        'which folder vb is running in
        activepath = Application.StartupPath

    End Sub
    Public Sub setfilelocations()

        activepath = Application.StartupPath

        fileloc_user = activepath & "\userfile.txt"
        If Dir$(fileloc_user) = "" Then
            Dim sw As New StreamWriter(fileloc_user, True)
            sw.WriteLine("1,admin,password,1")
            sw.Close()

        End If

        fileloc_seat = activepath & "\seatbooking.txt"
        If Dir$(fileloc_seat) = "" Then
            Dim sw As New StreamWriter(fileloc_seat, True)
            sw.Close()

        End If

        fileloc_snackdrink = activepath & "\snackdrink.txt"
        If Dir$(fileloc_snackdrink) = "" Then
            Dim sw As New StreamWriter(fileloc_snackdrink, True)
            sw.Close()

        End If

    End Sub

End Module
