﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SeatBooking
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_A1 = New System.Windows.Forms.Button()
        Me.btn_B1 = New System.Windows.Forms.Button()
        Me.btn_C1 = New System.Windows.Forms.Button()
        Me.btn_D1 = New System.Windows.Forms.Button()
        Me.btn_E1 = New System.Windows.Forms.Button()
        Me.btn_E2 = New System.Windows.Forms.Button()
        Me.btn_D2 = New System.Windows.Forms.Button()
        Me.btn_C2 = New System.Windows.Forms.Button()
        Me.btn_B2 = New System.Windows.Forms.Button()
        Me.btn_A2 = New System.Windows.Forms.Button()
        Me.btn_E3 = New System.Windows.Forms.Button()
        Me.btn_D3 = New System.Windows.Forms.Button()
        Me.btn_C3 = New System.Windows.Forms.Button()
        Me.btn_B3 = New System.Windows.Forms.Button()
        Me.btn_A3 = New System.Windows.Forms.Button()
        Me.btn_E4 = New System.Windows.Forms.Button()
        Me.btn_D4 = New System.Windows.Forms.Button()
        Me.btn_C4 = New System.Windows.Forms.Button()
        Me.btn_B4 = New System.Windows.Forms.Button()
        Me.btn_A4 = New System.Windows.Forms.Button()
        Me.btn_E5 = New System.Windows.Forms.Button()
        Me.btn_D5 = New System.Windows.Forms.Button()
        Me.btn_C5 = New System.Windows.Forms.Button()
        Me.btn_B5 = New System.Windows.Forms.Button()
        Me.btn_A5 = New System.Windows.Forms.Button()
        Me.dgv_seat = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_forename = New System.Windows.Forms.TextBox()
        Me.txt_surname = New System.Windows.Forms.TextBox()
        Me.txt_partyno = New System.Windows.Forms.TextBox()
        Me.btn_save = New System.Windows.Forms.Button()
        Me.btn_clearselection = New System.Windows.Forms.Button()
        Me.btn_clearall = New System.Windows.Forms.Button()
        Me.txt_movieinput = New System.Windows.Forms.TextBox()
        Me.lbl_movie = New System.Windows.Forms.Label()
        Me.btn_seatveiw = New System.Windows.Forms.Button()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.pbx_screen = New System.Windows.Forms.PictureBox()
        Me.lbl_assistance = New System.Windows.Forms.Label()
        Me.rbtn_yes = New System.Windows.Forms.RadioButton()
        Me.rbtn_no = New System.Windows.Forms.RadioButton()
        CType(Me.dgv_seat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbx_screen, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_A1
        '
        Me.btn_A1.Location = New System.Drawing.Point(35, 87)
        Me.btn_A1.Name = "btn_A1"
        Me.btn_A1.Size = New System.Drawing.Size(52, 52)
        Me.btn_A1.TabIndex = 0
        Me.btn_A1.Text = "A1"
        Me.btn_A1.UseVisualStyleBackColor = True
        '
        'btn_B1
        '
        Me.btn_B1.Location = New System.Drawing.Point(93, 87)
        Me.btn_B1.Name = "btn_B1"
        Me.btn_B1.Size = New System.Drawing.Size(52, 52)
        Me.btn_B1.TabIndex = 1
        Me.btn_B1.Text = "B1"
        Me.btn_B1.UseVisualStyleBackColor = True
        '
        'btn_C1
        '
        Me.btn_C1.Location = New System.Drawing.Point(151, 87)
        Me.btn_C1.Name = "btn_C1"
        Me.btn_C1.Size = New System.Drawing.Size(52, 52)
        Me.btn_C1.TabIndex = 2
        Me.btn_C1.Text = "C1"
        Me.btn_C1.UseVisualStyleBackColor = True
        '
        'btn_D1
        '
        Me.btn_D1.Location = New System.Drawing.Point(209, 87)
        Me.btn_D1.Name = "btn_D1"
        Me.btn_D1.Size = New System.Drawing.Size(52, 52)
        Me.btn_D1.TabIndex = 3
        Me.btn_D1.Text = "D1"
        Me.btn_D1.UseVisualStyleBackColor = True
        '
        'btn_E1
        '
        Me.btn_E1.Location = New System.Drawing.Point(267, 87)
        Me.btn_E1.Name = "btn_E1"
        Me.btn_E1.Size = New System.Drawing.Size(52, 52)
        Me.btn_E1.TabIndex = 4
        Me.btn_E1.Text = "E1"
        Me.btn_E1.UseVisualStyleBackColor = True
        '
        'btn_E2
        '
        Me.btn_E2.Location = New System.Drawing.Point(267, 145)
        Me.btn_E2.Name = "btn_E2"
        Me.btn_E2.Size = New System.Drawing.Size(52, 52)
        Me.btn_E2.TabIndex = 9
        Me.btn_E2.Text = "E2"
        Me.btn_E2.UseVisualStyleBackColor = True
        '
        'btn_D2
        '
        Me.btn_D2.Location = New System.Drawing.Point(209, 145)
        Me.btn_D2.Name = "btn_D2"
        Me.btn_D2.Size = New System.Drawing.Size(52, 52)
        Me.btn_D2.TabIndex = 8
        Me.btn_D2.Text = "D2"
        Me.btn_D2.UseVisualStyleBackColor = True
        '
        'btn_C2
        '
        Me.btn_C2.Location = New System.Drawing.Point(151, 145)
        Me.btn_C2.Name = "btn_C2"
        Me.btn_C2.Size = New System.Drawing.Size(52, 52)
        Me.btn_C2.TabIndex = 7
        Me.btn_C2.Text = "C2"
        Me.btn_C2.UseVisualStyleBackColor = True
        '
        'btn_B2
        '
        Me.btn_B2.Location = New System.Drawing.Point(93, 145)
        Me.btn_B2.Name = "btn_B2"
        Me.btn_B2.Size = New System.Drawing.Size(52, 52)
        Me.btn_B2.TabIndex = 6
        Me.btn_B2.Text = "B2"
        Me.btn_B2.UseVisualStyleBackColor = True
        '
        'btn_A2
        '
        Me.btn_A2.Location = New System.Drawing.Point(35, 145)
        Me.btn_A2.Name = "btn_A2"
        Me.btn_A2.Size = New System.Drawing.Size(52, 52)
        Me.btn_A2.TabIndex = 5
        Me.btn_A2.Text = "A2"
        Me.btn_A2.UseVisualStyleBackColor = True
        '
        'btn_E3
        '
        Me.btn_E3.Location = New System.Drawing.Point(267, 203)
        Me.btn_E3.Name = "btn_E3"
        Me.btn_E3.Size = New System.Drawing.Size(52, 52)
        Me.btn_E3.TabIndex = 14
        Me.btn_E3.Text = "E3"
        Me.btn_E3.UseVisualStyleBackColor = True
        '
        'btn_D3
        '
        Me.btn_D3.Location = New System.Drawing.Point(209, 203)
        Me.btn_D3.Name = "btn_D3"
        Me.btn_D3.Size = New System.Drawing.Size(52, 52)
        Me.btn_D3.TabIndex = 13
        Me.btn_D3.Text = "D3"
        Me.btn_D3.UseVisualStyleBackColor = True
        '
        'btn_C3
        '
        Me.btn_C3.Location = New System.Drawing.Point(151, 203)
        Me.btn_C3.Name = "btn_C3"
        Me.btn_C3.Size = New System.Drawing.Size(52, 52)
        Me.btn_C3.TabIndex = 12
        Me.btn_C3.Text = "C3"
        Me.btn_C3.UseVisualStyleBackColor = True
        '
        'btn_B3
        '
        Me.btn_B3.Location = New System.Drawing.Point(93, 203)
        Me.btn_B3.Name = "btn_B3"
        Me.btn_B3.Size = New System.Drawing.Size(52, 52)
        Me.btn_B3.TabIndex = 11
        Me.btn_B3.Text = "B3"
        Me.btn_B3.UseVisualStyleBackColor = True
        '
        'btn_A3
        '
        Me.btn_A3.Location = New System.Drawing.Point(35, 203)
        Me.btn_A3.Name = "btn_A3"
        Me.btn_A3.Size = New System.Drawing.Size(52, 52)
        Me.btn_A3.TabIndex = 10
        Me.btn_A3.Text = "A3"
        Me.btn_A3.UseVisualStyleBackColor = True
        '
        'btn_E4
        '
        Me.btn_E4.Location = New System.Drawing.Point(267, 261)
        Me.btn_E4.Name = "btn_E4"
        Me.btn_E4.Size = New System.Drawing.Size(52, 52)
        Me.btn_E4.TabIndex = 19
        Me.btn_E4.Text = "E4"
        Me.btn_E4.UseVisualStyleBackColor = True
        '
        'btn_D4
        '
        Me.btn_D4.Location = New System.Drawing.Point(209, 261)
        Me.btn_D4.Name = "btn_D4"
        Me.btn_D4.Size = New System.Drawing.Size(52, 52)
        Me.btn_D4.TabIndex = 18
        Me.btn_D4.Text = "D4"
        Me.btn_D4.UseVisualStyleBackColor = True
        '
        'btn_C4
        '
        Me.btn_C4.Location = New System.Drawing.Point(151, 261)
        Me.btn_C4.Name = "btn_C4"
        Me.btn_C4.Size = New System.Drawing.Size(52, 52)
        Me.btn_C4.TabIndex = 17
        Me.btn_C4.Text = "C4"
        Me.btn_C4.UseVisualStyleBackColor = True
        '
        'btn_B4
        '
        Me.btn_B4.Location = New System.Drawing.Point(93, 261)
        Me.btn_B4.Name = "btn_B4"
        Me.btn_B4.Size = New System.Drawing.Size(52, 52)
        Me.btn_B4.TabIndex = 16
        Me.btn_B4.Text = "B4"
        Me.btn_B4.UseVisualStyleBackColor = True
        '
        'btn_A4
        '
        Me.btn_A4.Location = New System.Drawing.Point(35, 261)
        Me.btn_A4.Name = "btn_A4"
        Me.btn_A4.Size = New System.Drawing.Size(52, 52)
        Me.btn_A4.TabIndex = 15
        Me.btn_A4.Text = "A4"
        Me.btn_A4.UseVisualStyleBackColor = True
        '
        'btn_E5
        '
        Me.btn_E5.Location = New System.Drawing.Point(267, 319)
        Me.btn_E5.Name = "btn_E5"
        Me.btn_E5.Size = New System.Drawing.Size(52, 52)
        Me.btn_E5.TabIndex = 24
        Me.btn_E5.Text = "E5"
        Me.btn_E5.UseVisualStyleBackColor = True
        '
        'btn_D5
        '
        Me.btn_D5.Location = New System.Drawing.Point(209, 319)
        Me.btn_D5.Name = "btn_D5"
        Me.btn_D5.Size = New System.Drawing.Size(52, 52)
        Me.btn_D5.TabIndex = 23
        Me.btn_D5.Text = "D5"
        Me.btn_D5.UseVisualStyleBackColor = True
        '
        'btn_C5
        '
        Me.btn_C5.Location = New System.Drawing.Point(151, 319)
        Me.btn_C5.Name = "btn_C5"
        Me.btn_C5.Size = New System.Drawing.Size(52, 52)
        Me.btn_C5.TabIndex = 22
        Me.btn_C5.Text = "C5"
        Me.btn_C5.UseVisualStyleBackColor = True
        '
        'btn_B5
        '
        Me.btn_B5.Location = New System.Drawing.Point(93, 319)
        Me.btn_B5.Name = "btn_B5"
        Me.btn_B5.Size = New System.Drawing.Size(52, 52)
        Me.btn_B5.TabIndex = 21
        Me.btn_B5.Text = "B5"
        Me.btn_B5.UseVisualStyleBackColor = True
        '
        'btn_A5
        '
        Me.btn_A5.Location = New System.Drawing.Point(35, 319)
        Me.btn_A5.Name = "btn_A5"
        Me.btn_A5.Size = New System.Drawing.Size(52, 52)
        Me.btn_A5.TabIndex = 20
        Me.btn_A5.Text = "A5"
        Me.btn_A5.UseVisualStyleBackColor = True
        '
        'dgv_seat
        '
        Me.dgv_seat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_seat.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5})
        Me.dgv_seat.Location = New System.Drawing.Point(556, 7)
        Me.dgv_seat.Name = "dgv_seat"
        Me.dgv_seat.RowTemplate.Height = 25
        Me.dgv_seat.Size = New System.Drawing.Size(543, 469)
        Me.dgv_seat.TabIndex = 26
        '
        'Column1
        '
        Me.Column1.HeaderText = "Seat"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Forename"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.HeaderText = "Surname"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.HeaderText = "Party No."
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.HeaderText = "Assistance?"
        Me.Column5.Name = "Column5"
        Me.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 403)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 15)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Forename"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 432)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 15)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Surname"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 461)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 15)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "Party number:"
        '
        'txt_forename
        '
        Me.txt_forename.Location = New System.Drawing.Point(104, 400)
        Me.txt_forename.Name = "txt_forename"
        Me.txt_forename.Size = New System.Drawing.Size(136, 23)
        Me.txt_forename.TabIndex = 31
        '
        'txt_surname
        '
        Me.txt_surname.Location = New System.Drawing.Point(104, 429)
        Me.txt_surname.Name = "txt_surname"
        Me.txt_surname.Size = New System.Drawing.Size(136, 23)
        Me.txt_surname.TabIndex = 32
        '
        'txt_partyno
        '
        Me.txt_partyno.Location = New System.Drawing.Point(104, 458)
        Me.txt_partyno.Name = "txt_partyno"
        Me.txt_partyno.Size = New System.Drawing.Size(136, 23)
        Me.txt_partyno.TabIndex = 33
        '
        'btn_save
        '
        Me.btn_save.Location = New System.Drawing.Point(386, 145)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Size = New System.Drawing.Size(101, 45)
        Me.btn_save.TabIndex = 34
        Me.btn_save.Text = "Save"
        Me.btn_save.UseVisualStyleBackColor = True
        '
        'btn_clearselection
        '
        Me.btn_clearselection.Location = New System.Drawing.Point(386, 196)
        Me.btn_clearselection.Name = "btn_clearselection"
        Me.btn_clearselection.Size = New System.Drawing.Size(101, 45)
        Me.btn_clearselection.TabIndex = 35
        Me.btn_clearselection.Text = "Clear selection"
        Me.btn_clearselection.UseVisualStyleBackColor = True
        '
        'btn_clearall
        '
        Me.btn_clearall.Location = New System.Drawing.Point(386, 252)
        Me.btn_clearall.Name = "btn_clearall"
        Me.btn_clearall.Size = New System.Drawing.Size(101, 45)
        Me.btn_clearall.TabIndex = 36
        Me.btn_clearall.Text = "Clear all"
        Me.btn_clearall.UseVisualStyleBackColor = True
        '
        'txt_movieinput
        '
        Me.txt_movieinput.Location = New System.Drawing.Point(366, 51)
        Me.txt_movieinput.Name = "txt_movieinput"
        Me.txt_movieinput.Size = New System.Drawing.Size(150, 23)
        Me.txt_movieinput.TabIndex = 37
        '
        'lbl_movie
        '
        Me.lbl_movie.AutoSize = True
        Me.lbl_movie.Location = New System.Drawing.Point(418, 33)
        Me.lbl_movie.Name = "lbl_movie"
        Me.lbl_movie.Size = New System.Drawing.Size(40, 15)
        Me.lbl_movie.TabIndex = 38
        Me.lbl_movie.Text = "Movie"
        '
        'btn_seatveiw
        '
        Me.btn_seatveiw.BackColor = System.Drawing.Color.DarkOrange
        Me.btn_seatveiw.Location = New System.Drawing.Point(386, 94)
        Me.btn_seatveiw.Name = "btn_seatveiw"
        Me.btn_seatveiw.Size = New System.Drawing.Size(101, 45)
        Me.btn_seatveiw.TabIndex = 39
        Me.btn_seatveiw.Text = "Go to seat veiwing"
        Me.btn_seatveiw.UseVisualStyleBackColor = False
        '
        'btn_exit
        '
        Me.btn_exit.BackColor = System.Drawing.Color.Red
        Me.btn_exit.Location = New System.Drawing.Point(418, 446)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(115, 49)
        Me.btn_exit.TabIndex = 40
        Me.btn_exit.Text = "Exit to menu"
        Me.btn_exit.UseVisualStyleBackColor = False
        '
        'pbx_screen
        '
        Me.pbx_screen.Image = Global.POS_for_Cinema_and_Co.My.Resources.Resources.screen
        Me.pbx_screen.Location = New System.Drawing.Point(35, 7)
        Me.pbx_screen.Name = "pbx_screen"
        Me.pbx_screen.Size = New System.Drawing.Size(284, 68)
        Me.pbx_screen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbx_screen.TabIndex = 81
        Me.pbx_screen.TabStop = False
        '
        'lbl_assistance
        '
        Me.lbl_assistance.AutoSize = True
        Me.lbl_assistance.Location = New System.Drawing.Point(299, 403)
        Me.lbl_assistance.Name = "lbl_assistance"
        Me.lbl_assistance.Size = New System.Drawing.Size(67, 15)
        Me.lbl_assistance.TabIndex = 82
        Me.lbl_assistance.Text = "Assistance?"
        '
        'rbtn_yes
        '
        Me.rbtn_yes.AutoSize = True
        Me.rbtn_yes.Location = New System.Drawing.Point(309, 421)
        Me.rbtn_yes.Name = "rbtn_yes"
        Me.rbtn_yes.Size = New System.Drawing.Size(42, 19)
        Me.rbtn_yes.TabIndex = 88
        Me.rbtn_yes.TabStop = True
        Me.rbtn_yes.Text = "Yes"
        Me.rbtn_yes.UseVisualStyleBackColor = True
        '
        'rbtn_no
        '
        Me.rbtn_no.AutoSize = True
        Me.rbtn_no.Location = New System.Drawing.Point(309, 446)
        Me.rbtn_no.Name = "rbtn_no"
        Me.rbtn_no.Size = New System.Drawing.Size(41, 19)
        Me.rbtn_no.TabIndex = 89
        Me.rbtn_no.TabStop = True
        Me.rbtn_no.Text = "No"
        Me.rbtn_no.UseVisualStyleBackColor = True
        '
        'SeatBooking
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(1114, 507)
        Me.Controls.Add(Me.rbtn_no)
        Me.Controls.Add(Me.rbtn_yes)
        Me.Controls.Add(Me.lbl_assistance)
        Me.Controls.Add(Me.pbx_screen)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.btn_seatveiw)
        Me.Controls.Add(Me.lbl_movie)
        Me.Controls.Add(Me.txt_movieinput)
        Me.Controls.Add(Me.btn_clearall)
        Me.Controls.Add(Me.btn_clearselection)
        Me.Controls.Add(Me.btn_save)
        Me.Controls.Add(Me.txt_partyno)
        Me.Controls.Add(Me.txt_surname)
        Me.Controls.Add(Me.txt_forename)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dgv_seat)
        Me.Controls.Add(Me.btn_E5)
        Me.Controls.Add(Me.btn_D5)
        Me.Controls.Add(Me.btn_C5)
        Me.Controls.Add(Me.btn_B5)
        Me.Controls.Add(Me.btn_A5)
        Me.Controls.Add(Me.btn_E4)
        Me.Controls.Add(Me.btn_D4)
        Me.Controls.Add(Me.btn_C4)
        Me.Controls.Add(Me.btn_B4)
        Me.Controls.Add(Me.btn_A4)
        Me.Controls.Add(Me.btn_E3)
        Me.Controls.Add(Me.btn_D3)
        Me.Controls.Add(Me.btn_C3)
        Me.Controls.Add(Me.btn_B3)
        Me.Controls.Add(Me.btn_A3)
        Me.Controls.Add(Me.btn_E2)
        Me.Controls.Add(Me.btn_D2)
        Me.Controls.Add(Me.btn_C2)
        Me.Controls.Add(Me.btn_B2)
        Me.Controls.Add(Me.btn_A2)
        Me.Controls.Add(Me.btn_E1)
        Me.Controls.Add(Me.btn_D1)
        Me.Controls.Add(Me.btn_C1)
        Me.Controls.Add(Me.btn_B1)
        Me.Controls.Add(Me.btn_A1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "SeatBooking"
        Me.Text = "SeatBooking"
        CType(Me.dgv_seat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbx_screen, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_A1 As Button
    Friend WithEvents btn_B1 As Button
    Friend WithEvents btn_C1 As Button
    Friend WithEvents btn_D1 As Button
    Friend WithEvents btn_E1 As Button
    Friend WithEvents btn_E2 As Button
    Friend WithEvents btn_D2 As Button
    Friend WithEvents btn_C2 As Button
    Friend WithEvents btn_B2 As Button
    Friend WithEvents btn_A2 As Button
    Friend WithEvents btn_E3 As Button
    Friend WithEvents btn_D3 As Button
    Friend WithEvents btn_C3 As Button
    Friend WithEvents btn_B3 As Button
    Friend WithEvents btn_A3 As Button
    Friend WithEvents btn_E4 As Button
    Friend WithEvents btn_D4 As Button
    Friend WithEvents btn_C4 As Button
    Friend WithEvents btn_B4 As Button
    Friend WithEvents btn_A4 As Button
    Friend WithEvents btn_E5 As Button
    Friend WithEvents btn_D5 As Button
    Friend WithEvents btn_C5 As Button
    Friend WithEvents btn_B5 As Button
    Friend WithEvents btn_A5 As Button
    Friend WithEvents dgv_seat As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_forename As TextBox
    Friend WithEvents txt_surname As TextBox
    Friend WithEvents txt_partyno As TextBox
    Friend WithEvents btn_save As Button
    Friend WithEvents btn_clearselection As Button
    Friend WithEvents btn_clearall As Button
    Friend WithEvents lbl_movie As Label
    Friend WithEvents btn_seatveiw As Button
    Friend WithEvents btn_exit As Button
    Friend WithEvents pbx_screen As PictureBox
    Friend WithEvents lbl_assistance As Label
    Friend WithEvents rbtn_yes As RadioButton
    Friend WithEvents rbtn_no As RadioButton
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Public WithEvents txt_movieinput As TextBox
End Class
