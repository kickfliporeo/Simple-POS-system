﻿Imports System.IO
Public Class CheckSales
    Dim linecount As Integer
    Dim newstockid As Integer
    Dim rowindex As Integer

    Private Sub fillgrid()

        dgv_sales.Rows.Clear()

        linecount = File.ReadAllLines(fileloc_snackdrink).Length

        Dim sr As New StreamReader(fileloc_snackdrink)
        Dim oneline As String
        Dim oneuser() As String

        While sr.Peek() >= 0

            oneline = sr.ReadLine()
            oneuser = oneline.Split(",")

            Dim index = dgv_sales.Rows.Add
            dgv_sales.Rows(index).SetValues(oneuser)

        End While

        sr.Close()

        dgv_sales.RowHeadersVisible = False
    End Sub

    Private Sub setbuttons()

        btn_save.Enabled = True
        btn_clear.Enabled = True
        btn_first.Enabled = True
        btn_previous.Enabled = True
        btn_next.Enabled = True
        btn_last.Enabled = True

    End Sub



    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click

        Me.Visible = False
        MainMenu.Visible = True

    End Sub

    Private Sub CheckSales_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        setfilelocations()
        setbuttons()
        fillgrid()

    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        Dim snackdrinkID As String
        Dim newsnackdrink As String
        Dim newprice As Decimal
        Dim newstock As Integer

        newsnackdrink = txt_snackdrink.Text
        newprice = Val(txt_price.Text)
        newstock = Val(txt_stock.Text)

        snackdrinkID = newsnackdrink & "," & newprice & "," & newstock

        Dim sw As New StreamWriter(fileloc_snackdrink, True)

        sw.WriteLine(snackdrinkID)
        sw.Close()
        fillgrid()

        txt_snackdrink.Text = ""
        txt_price.Text = ""
        txt_stock.Text = ""

        btn_save.Enabled = True

    End Sub

    Private Sub First()

        rowindex = 0

        txt_snackdrink.Text = dgv_sales.Rows(rowindex).Cells(0).Value
        txt_price.Text = dgv_sales.Rows(rowindex).Cells(1).Value
        txt_stock.Text = dgv_sales.Rows(rowindex).Cells(2).Value


        dgv_sales.ClearSelection() 'clears blue bars
        dgv_sales.Rows(rowindex).Selected = True

    End Sub

    Private Sub last()

        rowindex = linecount - 1 'we count from 0, so we need to subtract 1

        txt_snackdrink.Text = dgv_sales.Rows(rowindex).Cells(0).Value
        txt_price.Text = dgv_sales.Rows(rowindex).Cells(1).Value
        txt_stock.Text = dgv_sales.Rows(rowindex).Cells(2).Value


        dgv_sales.ClearSelection() 'clears blue bars
        dgv_sales.Rows(rowindex).Selected = True


    End Sub

    Private Sub Previous()

        If rowindex > 0 Then

            rowindex = rowindex - 1

        Else

            MsgBox("Sorry, We are already at the first record!")

        End If

        txt_snackdrink.Text = dgv_sales.Rows(rowindex).Cells(0).Value
        txt_price.Text = dgv_sales.Rows(rowindex).Cells(1).Value
        txt_stock.Text = dgv_sales.Rows(rowindex).Cells(2).Value


        dgv_sales.ClearSelection() 'clears blue bars
        dgv_sales.Rows(rowindex).Selected = True

    End Sub

    Private Sub Nextuser()

        If rowindex < (linecount - 1) Then

            rowindex = rowindex + 1

        Else

            MsgBox("Sorry, We are already at the last record!")

        End If

        txt_snackdrink.Text = dgv_sales.Rows(rowindex).Cells(0).Value
        txt_price.Text = dgv_sales.Rows(rowindex).Cells(1).Value
        txt_stock.Text = dgv_sales.Rows(rowindex).Cells(2).Value


        dgv_sales.ClearSelection() 'clears blue bar
        dgv_sales.Rows(rowindex).Selected = True

    End Sub

    Private Sub btn_first_Click(sender As Object, e As EventArgs) Handles btn_first.Click

        First()

    End Sub

    Private Sub btn_previous_Click(sender As Object, e As EventArgs) Handles btn_previous.Click

        Previous()

    End Sub

    Private Sub btn_next_Click(sender As Object, e As EventArgs) Handles btn_next.Click

        Nextuser()

    End Sub

    Private Sub btn_last_Click(sender As Object, e As EventArgs) Handles btn_last.Click

        last()

    End Sub

    Private Sub btn_clear_Click(sender As Object, e As EventArgs) Handles btn_clear.Click
        Dim lookingat_snackdrink As String
        Dim lookingat_price As Integer
        Dim lookingat_stock As Decimal
        Dim counter As Integer

        If MsgBox("Are you sure you wish to delete?", vbYesNo) = vbYes Then

            Dim sw As New StreamWriter(fileloc_snackdrink, False)

            For counter = 0 To (linecount)


                lookingat_price = dgv_sales.Rows(counter).Cells(1).Value
                lookingat_stock = dgv_sales.Rows(counter).Cells(2).Value


                If lookingat_price <> txt_price.Text Then

                    sw.WriteLine(lookingat_price & "," & lookingat_stock)

                End If

            Next

            sw.Close()
            MsgBox("Data has been deleted!")

        End If

        fillgrid()

    End Sub
End Class