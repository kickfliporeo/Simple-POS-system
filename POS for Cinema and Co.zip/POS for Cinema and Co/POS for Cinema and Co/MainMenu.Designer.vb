﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_sbookings = New System.Windows.Forms.Button()
        Me.btn_FandD = New System.Windows.Forms.Button()
        Me.btn_elogin = New System.Windows.Forms.Button()
        Me.btn_csales = New System.Windows.Forms.Button()
        Me.btn_exit = New System.Windows.Forms.Button()
        Me.lbl_level = New System.Windows.Forms.Label()
        Me.txt_access = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn_sbookings
        '
        Me.btn_sbookings.BackColor = System.Drawing.Color.DimGray
        Me.btn_sbookings.ForeColor = System.Drawing.Color.White
        Me.btn_sbookings.Location = New System.Drawing.Point(37, 62)
        Me.btn_sbookings.Name = "btn_sbookings"
        Me.btn_sbookings.Size = New System.Drawing.Size(122, 104)
        Me.btn_sbookings.TabIndex = 0
        Me.btn_sbookings.Text = "Seat bookings"
        Me.btn_sbookings.UseVisualStyleBackColor = False
        '
        'btn_FandD
        '
        Me.btn_FandD.BackColor = System.Drawing.Color.DimGray
        Me.btn_FandD.ForeColor = System.Drawing.Color.White
        Me.btn_FandD.Location = New System.Drawing.Point(209, 62)
        Me.btn_FandD.Name = "btn_FandD"
        Me.btn_FandD.Size = New System.Drawing.Size(122, 104)
        Me.btn_FandD.TabIndex = 1
        Me.btn_FandD.Text = "Food and drink"
        Me.btn_FandD.UseVisualStyleBackColor = False
        '
        'btn_elogin
        '
        Me.btn_elogin.BackColor = System.Drawing.Color.DimGray
        Me.btn_elogin.ForeColor = System.Drawing.Color.White
        Me.btn_elogin.Location = New System.Drawing.Point(209, 203)
        Me.btn_elogin.Name = "btn_elogin"
        Me.btn_elogin.Size = New System.Drawing.Size(122, 104)
        Me.btn_elogin.TabIndex = 5
        Me.btn_elogin.Text = "Edit login"
        Me.btn_elogin.UseVisualStyleBackColor = False
        '
        'btn_csales
        '
        Me.btn_csales.BackColor = System.Drawing.Color.DimGray
        Me.btn_csales.ForeColor = System.Drawing.Color.White
        Me.btn_csales.Location = New System.Drawing.Point(37, 203)
        Me.btn_csales.Name = "btn_csales"
        Me.btn_csales.Size = New System.Drawing.Size(122, 104)
        Me.btn_csales.TabIndex = 4
        Me.btn_csales.Text = "Check sales"
        Me.btn_csales.UseVisualStyleBackColor = False
        '
        'btn_exit
        '
        Me.btn_exit.BackColor = System.Drawing.Color.Red
        Me.btn_exit.Location = New System.Drawing.Point(122, 328)
        Me.btn_exit.Name = "btn_exit"
        Me.btn_exit.Size = New System.Drawing.Size(122, 104)
        Me.btn_exit.TabIndex = 6
        Me.btn_exit.Text = "Back to menu"
        Me.btn_exit.UseVisualStyleBackColor = False
        '
        'lbl_level
        '
        Me.lbl_level.AutoSize = True
        Me.lbl_level.Location = New System.Drawing.Point(86, 26)
        Me.lbl_level.Name = "lbl_level"
        Me.lbl_level.Size = New System.Drawing.Size(37, 15)
        Me.lbl_level.TabIndex = 7
        Me.lbl_level.Text = "Level:"
        '
        'txt_access
        '
        Me.txt_access.Location = New System.Drawing.Point(133, 23)
        Me.txt_access.Name = "txt_access"
        Me.txt_access.ReadOnly = True
        Me.txt_access.Size = New System.Drawing.Size(135, 23)
        Me.txt_access.TabIndex = 8
        '
        'MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkGray
        Me.ClientSize = New System.Drawing.Size(385, 499)
        Me.Controls.Add(Me.txt_access)
        Me.Controls.Add(Me.lbl_level)
        Me.Controls.Add(Me.btn_exit)
        Me.Controls.Add(Me.btn_elogin)
        Me.Controls.Add(Me.btn_csales)
        Me.Controls.Add(Me.btn_FandD)
        Me.Controls.Add(Me.btn_sbookings)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "MainMenu"
        Me.Text = "MainMenu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_sbookings As Button
    Friend WithEvents btn_FandD As Button
    Friend WithEvents btn_elogin As Button
    Friend WithEvents btn_csales As Button
    Friend WithEvents btn_exit As Button
    Friend WithEvents lbl_level As Label
    Friend WithEvents txt_access As TextBox
End Class
